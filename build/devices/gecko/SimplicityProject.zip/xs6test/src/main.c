/**************************************************************************//**
 * @file
 * @brief FreeRTOS Blink Demo for Energy Micro EFM32GG_STK3700 Starter Kit
 * @version 5.0.0
 ******************************************************************************
 * @section License
 * <b>Copyright 2015 Silicon Labs, Inc. http://www.silabs.com</b>
 *******************************************************************************
 *
 * This file is licensed under the Silabs License Agreement. See the file
 * "Silabs_License_Agreement.txt" for details. Before using this software for
 * any purpose, you must agree to the terms of that agreement.
 *
 ******************************************************************************/
#define mxDebug 1
#define USE_UART0_FOR_DEBUG 0
#define USE_USART0_FOR_DEBUG 1	// USART0 Loc #5 (PC0-TX, PC1-RX)
#define ENABLE_SPI 0
#define CLOCK_LT_32MHz 0		// set to 1 to enable a lower speed clock
#define tryRTC 0
#define tryRTC1 0
#define tryRTC2 0

#include <stdio.h>
#include <stdlib.h>

#include "FreeRTOSConfig.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
#include "croutine.h"

#include "em_chip.h"
#include "bsp.h"
#include "bsp_trace.h"

#include "sleep.h"


/* MODDABLE */
#define __XS6PLATFORMMINIMAL__
#include "xs.h"
#include "xs6gecko.h"

#include "xs6Platform.h"
#include "modInstrumentation.h"

xsMachine *gThe;        // the one XS6 virtual machine running

#if mxDebug
#include "em_device.h"
#include "em_cmu.h"
#include "em_gpio.h"
#include "em_usart.h"
#include "em_system.h"

#if USE_UART0_FOR_DEBUG
	#define COM_PORT gpioPortE
	#define UART_TX_pin 0
	#define UART_RX_pin 1
	#define DEBUG_UART	UART0
#elif USE_USART0_FOR_DEBUG
	#define COM_PORT gpioPortC
	#define UART_TX_pin 0
	#define UART_RX_pin 1
	#define DEBUG_UART	USART0
#else
	#define COM_PORT gpioPortD
	#define UART_TX_pin 0
	#define UART_RX_pin 1
	#define DEBUG_UART	USART1
#endif

#endif

#if ENABLE_SPI
	#define SPI_PORT	gpioPortD
	#define SPI_MOSI	0
	#define SPI_SCK		2
	#define SPI_CS		3
	#define SPI_RST		4
	#define SPI_DC		5
#endif

void modLog_transmit(const char *msg);
void ESP_putc(int c);
int ESP_getc(void);
uint8_t ESP_isReadable();
extern void fx_putc(void *refcon, char c);

/*  /MODDABLE */

#define STACK_SIZE_FOR_TASK    (configMINIMAL_STACK_SIZE + 10)
#define TASK_PRIORITY          (tskIDLE_PRIORITY + 1)

#if tryRTC
#include "em_rtc.h"

#define WAKE_INTERVAL_MS 1
uint32_t rtc_Hz;
volatile uint8_t rtc_if;
void RTC_IRQHandler (void)
{
  rtc_if = RTC->IF;
  RTC->IFC = rtc_if;
}
#endif

#if tryRTC1
#include "rtcdriver.h"

uint32_t gecko_milliseconds(void) {
	uint64_t ticks = RTCDRV_GetWallClockTicks64();
	uint32_t milliseconds = RTCDRV_TicksToMsec(ticks);
	return milliseconds;
}
#elif tryRTC2
#include "em_timer.h"

#define ONE_MILLISECOND_BASE_VALUE_COUNT             1000
#define ONE_SECOND_TIMER_COUNT                        13672
#define MILLISECOND_DIVISOR                           13.672

volatile uint64_t base_value = 0;
volatile bool timer1_overflow = false;
volatile uint32_t msTicks = 0;

void TIMER3_IRQHandler(void)
{
      timer1_overflow = true;
      base_value += ONE_MILLISECOND_BASE_VALUE_COUNT;
      TIMER_IntClear(TIMER3, TIMER_IF_OF);
}
uint64_t get_time_in_ms()
{
      // Clear our overflow indicator
      timer1_overflow = false;

      // Get the current count
      uint16_t count = TIMER3->CNT;

      // Get a copy of the base value
      uint64_t copy_of_base_value = base_value;

      // Now check to make sure that the ISR didn't fire while in here
      // If it did, then grab the values again
      if (timer1_overflow)
      {
            count = TIMER3->CNT;
            copy_of_base_value = base_value;
      }

      // Now calculate the number of milliseconds the program has run
      return copy_of_base_value + count / MILLISECOND_DIVISOR;
}
uint32_t gecko_milliseconds(void) {
	uint64_t ms = get_time_in_ms();
	return ms;
}
#else

uint32_t gecko_milliseconds(void)
{
	return xTaskGetTickCount();
}
#endif

void gecko_delay(uint32_t ms)
{
	vTaskDelay(ms);		// may not be accurate - need to check vTaskDelay tick
}


xsCallback xsHostModuleAt(xsIndex i)
{
    return NULL;
}

#if mxDebug

void modLog_transmit(const char *msg)
{
	uint8_t c;
	if (gThe) {
		while (0 != (c = c_read8(msg++)))
			fx_putc(gThe, c);
		fx_putc(gThe, 13);
		fx_putc(gThe, 10);
		fx_putc(gThe, 0);
	}
	else {
		while (0 != (c = c_read8(msg++)))
			ESP_putc(c);
		ESP_putc(13);
		ESP_putc(10);
		ESP_putc(0);
	}
}

//void fx_putc(void *unused, char c)
//{
//	ESP_putc(c);
//}

void ESP_putc(int c) {
    while( !(DEBUG_UART->STATUS & (1 << 6)) ); // wait for TX buffer to empty
//    while(USART_GetFlagStatus(DEBUG_UART, USART_FLAG_TXE) == RESET ); // wait for TX buffer to empty
    DEBUG_UART->TXDATA = c;       // print each character of the test string
}

int ESP_getc(void) {
	if (!ESP_isReadable())
		return -1;
	return DEBUG_UART->RXDATA;
//	return DEBUG_UART->DR & 0xff;
}

uint8_t ESP_isReadable() {
	if (DEBUG_UART->STATUS & (1<<7))
		return 1;
//	if (USART_GetFlagStatus(DEBUG_UART, USART_FLAG_RXNE) == SET)
//		return 1;
	return 0;
}
#else
void modLog_transmit(const char *msg) { }
void ESP_putc(int c) { }
int ESP_getc(void) { return -1; }
uint8_t ESP_isReadable() { return 0; }
#endif

void setup() {
    gThe = ESP_cloneMachine();

    xsBeginHost(gThe);
        fxRunModule(the, (const xsStringValue)"main");
    xsEndHost(gThe);
}

void loop()
{
    xsMachine *the = gThe;

    if (!the)
        return;

    int delayMS = modTimersCheck();
#if 1 // def mxDebug
    if (ESP_isReadable()) {
        if (triggerDebugCommand(the)) {
            if (modTimersNextScript() > 500) {      // if a script is not likely to fire within half a second, break immediately
                xsBeginHost(the);
                xsDebugger();
                xsEndHost(the);
            }
        }
        delayMS = modTimersCheck();
    }
#endif
    if (delayMS)
        delay((delayMS < 5) ? delayMS : 5);
}


void xs6Loop(void *pvParameter)
{
	setup();
	while (true)
		loop();
}

/**************************************************************************//**
 * @brief  Main function
 *****************************************************************************/
int main(void)
{
  /* Chip errata */
  CHIP_Init();
  /* If first word of user data page is non-zero, enable eA Profiler trace */
  BSP_TraceProfilerSetup();


#if mxDebug
#if CLOCK_LT_32MHz
  CMU->CTRL |= (1 << 14);                         // Set HF clock divider to /2 to keep core frequency <32MHz
#endif
  CMU->OSCENCMD |= 0x4;                           // Enable XTAL Oscillator
  while(! (CMU->STATUS & 0x8) );                  // Wait for XTAL osc to stabilize
  CMU->CMD = 0x2;                                 // Select HF XTAL osc as system clock source. 48MHz XTAL, but we divided the system clock by 2, therefore our HF clock should be 24MHz


//  GPIO->P[COM_PORT].MODEL = (1 << 4) | (4 << 0);  // Configure PD0 as digital output and PD1 as input
//  GPIO->P[COM_PORT].DOUTSET = (1 << UART_TX_pin); // Initialize PD0 high since UART TX idles high (otherwise glitches can occur)
  GPIO_PinModeSet(COM_PORT, UART_TX_pin, gpioModePushPull, 1);
  GPIO_PinModeSet(COM_PORT, UART_RX_pin, gpioModeInput, 0);

  // Use default value for USART1->CTRL: asynch mode, x16 OVS, lsb first, CLK idle low
  // Default frame options: 8-none-1-none
#if USE_UART0_FOR_DEBUG
  CMU->HFPERCLKEN0 = CMU_HFPERCLKEN0_GPIO | CMU_HFPERCLKEN0_UART0 | CMU_HFPERCLKEN0_USART1;        // Enable GPIO, and UART0 peripheral clocks (GG ref manual 11.5.18)
#if CLOCK_LT_32MHz
  UART0->CLKDIV = (48  << 6);                               // 48  will give 115200 baud rate (using 16-bit oversampling with 24MHz peripheral clock)
#else
  UART0->CLKDIV = (96  << 6);                               // 96  will give 115200 baud rate (using 16-bit oversampling with 48MHz peripheral clock)
#endif
  UART0->CMD = (1 << 11) | (1 << 10) | (1 << 2) | (1 << 0); // Clear RX/TX buffers and shif regs, Enable Transmitter and Receiver
  UART0->IFC = 0x1FF9;                                      // clear all USART interrupt flags
  UART0->ROUTE = 0x103;                                     // Enable TX and RX pins, use location #1 (UART TX and RX located at PE0 and PE1, see EFM32GG990 datasheet for details)
#elif USE_USART0_FOR_DEBUG
  CMU->HFPERCLKEN0 = CMU_HFPERCLKEN0_GPIO | CMU_HFPERCLKEN0_USART0; // | CMU_HFPERCLKEN0_USART1;        // Enable GPIO, and USART0 peripheral clocks (GG ref manual 11.5.18)
#if CLOCK_LT_32MHz
  USART0->CLKDIV = (48  << 6);                               // 48  will give 115200 baud rate (using 16-bit oversampling with 24MHz peripheral clock)
#else
  USART0->CLKDIV = (96  << 6);                               // 96  will give 115200 baud rate (using 16-bit oversampling with 48MHz peripheral clock)
#endif
  USART0->CMD = (1 << 11) | (1 << 10) | (1 << 2) | (1 << 0); // Clear RX/TX buffers and shif regs, Enable Transmitter and Receiver
  USART0->IFC = 0x1FF9;                                      // clear all USART interrupt flags
  USART0->ROUTE = 0x503;                                     // Enable TX and RX pins, use location #5 (USART0 TX and RX located at PC0 and PC1, see EFM32GG990 datasheet for details)
#else
  CMU->HFPERCLKEN0 = CMU_HFPERCLKEN0_GPIO | CMU_HFPERCLKEN0_USART1;        // Enable GPIO, and USART1 peripheral clocks (GG ref manual 11.5.18)
  USART1->CLKDIV = (48  << 6);                               // 48  will give 115200 baud rate (using 16-bit oversampling with 24MHz peripheral clock)
  USART1->CMD = (1 << 11) | (1 << 10) | (1 << 2) | (1 << 0); // Clear RX/TX buffers and shif regs, Enable Transmitter and Receiver
  USART1->IFC = 0x1FF9;                                      // clear all USART interrupt flags
  USART1->ROUTE = 0x103;                                     // Enable TX and RX pins, use location #1 (UART TX and RX located at PD0 and PD1, see EFM32GG990 datasheet for details)
#endif
#endif

#if ENABLE_SPI
  // Enable the GPIO pins for the USART, starting with CS
  // This is to avoid clocking the flash chip when we set CLK high
  GPIO_PinModeSet(SPI_PORT, SPI_CS, gpioModePushPull, 1);         // CS
//  GPIO_PinModeSet(SPI_PORT, 8, gpioModePushPull, 1);         // MicroSD CS
  GPIO_PinModeSet(SPI_PORT, SPI_MOSI, gpioModePushPull, 0);         // MOSI
//  GPIO_PinModeSet(SPI_PORT, 1, gpioModeInput, 0);         // MISO
  GPIO_PinModeSet(SPI_PORT, SPI_SCK, gpioModePushPull, 1);         // CLK

  // Enable the GPIO pins for the misc signals, leave pulled high
  GPIO_PinModeSet(SPI_PORT, SPI_DC, gpioModePushPull, 1);         // DC
  GPIO_PinModeSet(SPI_PORT, SPI_RST, gpioModePushPull, 1);         // RST

  CMU->HFPERCLKEN0 |=             CMU_HFPERCLKEN0_USART1;
#if 1
  // Initialize and enable the USART
//  USART_InitSync_TypeDef init = USART_INITSYNC_DEFAULT;
//  init.msbf = true;
//  CMU_ClockEnable(cmuClock_USART1, true);		// done above
  USART_InitSync_TypeDef init = {                                                                                           \
    usartEnable,       /* Enable RX/TX when init completed. */                                \
	48000000,                 /* 48MHz clock (0 for current configured reference clock). */ \
	48000000,	/* 1000000,           /* 1 Mbits/s. */                                                       \
    usartDatabits8,    /* 8 databits. */                                                      \
    true,              /* Master mode. */                                                     \
    true,             /* Send most significant bit first. */                                \
    usartClockMode0,   /* Clock idle low, sample on rising edge. */                           \
    false,             /* Not USART PRS input mode. */                                        \
    usartPrsRxCh0,     /* PRS channel 0. */                                                   \
    false              /* No AUTOTX mode. */                                                  \
  };

  USART_InitSync(USART1, &init);

//  USART1->CTRL |= USART_CTRL_AUTOCS;

  // Connect the USART signals to the GPIO peripheral
  USART1->ROUTE = /* USART_ROUTE_RXPEN | */ USART_ROUTE_TXPEN |
              USART_ROUTE_CLKPEN | /* USART_ROUTE_CSPEN | */
              USART_ROUTE_LOCATION_LOC1;
#else
  // Configure SPI Port (USART1 in sync mode)
  USART1->CTRL = (1 << 30) | (1 << 10) | (1 << 0);           // Transmit MSB first, use SPI mode 0 (0,0), Disable majority voting, use manual chip-select
  USART1->CLKDIV = 0; // (16 << 6);                                 // CLKDIV set to 16 = 2,4MHz
  USART1->CMD = (1 << 11) | (1 << 10) | (1 << 4) | (1 << 2) | (1 << 0); // Clear RX and TX buffers and shift regs, enable master mode, enable transmitter/receiver
  USART1->IFC = 0x1FF9;                                      // Clear USART1 interrupt flags
  USART1->ROUTE = (1 << 8) | (1 << 3) | (1 << 1); // Use USART1 location #1, enable CLK, and MOSI pins

#endif

#endif


#if tryRTC
  /* Initialize RTC. */
  CMU_ClockEnable(cmuClock_RTC, true);
  rtc_Hz = CMU_ClockFreqGet(cmuClock_RTC);
  RTC->FREEZE = RTC_FREEZE_REGFREEZE;
  RTC->COMP0 = (WAKE_INTERVAL_MS * rtc_Hz) / 1000;
  RTC->IFC = ~0U;
  RTC->IEN |= RTC_IEN_COMP0;
  RTC->CTRL = RTC_CTRL_COMP0TOP | RTC_CTRL_EN;
  RTC->FREEZE = 0;
  NVIC_EnableIRQ(RTC_IRQn);
#endif
#if tryRTC1
  RTCDRV_Init();
#endif
#if tryRTC2
  CMU_ClockEnable(cmuClock_TIMER3, true);

  // Create a timerInit object, based on the API default
  TIMER_Init_TypeDef timerInit = TIMER_INIT_DEFAULT;
  timerInit.prescale = timerPrescale1024;

  TIMER_IntEnable(TIMER3, TIMER_IF_OF);

  // Enable TIMER0 interrupt vector in NVIC
  NVIC_EnableIRQ(TIMER3_IRQn);

  // Set TIMER Top value
  TIMER_TopSet(TIMER3, ONE_SECOND_TIMER_COUNT);

  TIMER_Init(TIMER3, &timerInit);

  // Wait for the timer to get going
  while (TIMER3->CNT == 0)
        ;

#endif

  /* Initialize SLEEP driver, no calbacks are used */
  SLEEP_Init(NULL, NULL);
#if (configSLEEP_MODE < 3)
  /* do not let to sleep deeper than define */
  SLEEP_SleepBlockBegin((SLEEP_EnergyMode_t)(configSLEEP_MODE+1));
#endif

  xTaskCreate( xs6Loop, (const char *) "xs6Loop", 4096 /* 1024 + 512 */ , NULL, TASK_PRIORITY, NULL);

  /*Start FreeRTOS Scheduler*/
  vTaskStartScheduler();

  return 0;
}

void printErrorMsg(const char * errMsg)
{
   while(*errMsg != '\0'){
	   ESP_putc(*errMsg);
      ++errMsg;
   }
}

enum { r0, r1, r2, r3, r12, lr, pc, psr };

void HardFault_HandlerC(uint32_t *stack)
{
   static char msg[80];
   sprintf(msg, "r0  = 0x%08x\n", stack[r0]);  printErrorMsg(msg);
   sprintf(msg, "r1  = 0x%08x\n", stack[r1]);  printErrorMsg(msg);
   sprintf(msg, "r2  = 0x%08x\n", stack[r2]);  printErrorMsg(msg);
   sprintf(msg, "r3  = 0x%08x\n", stack[r3]);  printErrorMsg(msg);
   sprintf(msg, "r12 = 0x%08x\n", stack[r12]); printErrorMsg(msg);
   sprintf(msg, "lr  = 0x%08x\n", stack[lr]);  printErrorMsg(msg);
   sprintf(msg, "pc  = 0x%08x\n", stack[pc]);  printErrorMsg(msg);
   sprintf(msg, "psr = 0x%08x\n", stack[psr]); printErrorMsg(msg);
   sprintf(msg, "ADDR= 0x%08x\n", (unsigned int) (*((volatile uint32_t *)(0xE000ED28)))); printErrorMsg(msg);
}

void HardFault_Handler(void)
{
  /*
   * Get the appropriate stack pointer, depending on our mode,
   * and use it as the parameter to the C handler. This function
   * will never return
   */
  __asm("TST   LR, #4");
  __asm("ITE   EQ");
  __asm("MRSEQ R0, MSP");
  __asm("MRSNE R0, PSP");
  __asm("B HardFault_HandlerC");
}
